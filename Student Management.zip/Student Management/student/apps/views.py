from django.shortcuts import render, redirect
from .models import Register



# Create your views here.



def Index(request):
    return render(request, 'index.html')



def Add(request):
    if request.method == 'POST':
        name = request.POST['name']
        father = request.POST['father']
        email = request.POST['email']
        gender = request.POST['gender']
        phone = request.POST['phone']
        classess = request.POST['classess']
        pincode = request.POST['pincode']
        address = request.POST['address']
        fee = request.POST['fee']
        ad = Register(name=name, father=father, email=email, gender=gender, phone=phone, classess=classess, pincode=pincode, address=address, fee=fee)
        ad.save()
    return redirect('/')



def View(request):
    ad = Register.objects.all()
    return render(request, 'view.html', {'ad':ad})



def Delete(request, id):
    ad = Register.objects.get(id = id)
    ad.delete()
    return redirect('/')



def Update(request, id):
    ad = Register.objects.get(id=id)
    return render(request, 'update.html',{'ad':ad})



def Edit(request, id):
    ad = Register.objects.get(id = id)
    ad.name = request.POST['name']
    ad.father = request.POST['father']
    ad.email = request.POST['email']
    ad.gender = request.POST['gender']
    ad.phone = request.POST['phone']
    ad.classess = request.POST['classess']
    ad.pincode = request.POST['pincode']
    ad.address = request.POST['address']
    ad.fee = request.POST['fee']
    ad.save()
    return redirect('/view')


    