from django.db import models

# Create your models here.

class Register(models.Model):
    name = models.CharField(max_length=50)
    father = models.CharField(max_length=50)
    email = models.CharField(max_length=50)
    gender = models.CharField(max_length=20)
    phone = models.CharField(max_length=15)
    classess = models.CharField(max_length=10)
    pincode = models.CharField(max_length=10)
    address = models.CharField(max_length=150)
    fee = models.CharField(max_length=5)

    def __str__(self) -> str:
        return self.name + " , " + ' ' + self.father
