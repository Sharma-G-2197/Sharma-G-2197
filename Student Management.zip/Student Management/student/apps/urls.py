from django.contrib import admin
from django.urls import path, include
from .import views



urlpatterns = [
    path('', views.Index, name='index'),
    path('add', views.Add, name='add'),
    path('view', views.View, name='view'),
    path('delete/<int:id>/', views.Delete, name='delete'),
    path('update/<int:id>/', views.Update, name='update'),
    path('edit/<int:id>/', views.Edit, name='edit'),

]
